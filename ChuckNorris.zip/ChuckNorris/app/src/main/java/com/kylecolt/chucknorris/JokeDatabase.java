package com.kylecolt.chucknorris;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

public class JokeDatabase extends SQLiteOpenHelper
{

    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "joke.db";
    private static JokeDatabase jDB;

    public JokeDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);;
    }

    public static JokeDatabase getInstance(Context context) {
        if (jDB == null) {
            jDB = new JokeDatabase(context);
        }
        return jDB;
    }
    private static final class JokeTable {
        private static final String TABLE = "jokes";
        private static final String COL_ID = "_id";
        private static final String COL_J = "joke";


    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        db.execSQL("create table "+ JokeTable.TABLE+" (" +
                JokeTable.COL_ID+" integer primary key autoincrement , " +
                JokeTable.COL_J+ "text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("drop table if exists " + JokeTable.TABLE);
        onCreate(db);
    }

    public void addJoke(Joke j)
    {
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(JokeTable.COL_J, j.getJoke());
        db.insert(JokeTable.TABLE, null, values);


    }

    public ArrayList<Joke> getAllElements() {

        ArrayList<Joke> list = new ArrayList<Joke>();

        // Select All Query
        String selectQuery = "SELECT  * FROM " + JokeTable.TABLE;

        SQLiteDatabase db = this.getReadableDatabase();
        try {

            Cursor cursor = db.rawQuery(selectQuery, null);
            try {

                // looping through all rows and adding to list
                if (cursor.moveToFirst()) {
                    do {
                        Joke obj = new Joke();
                        //only one column
                        obj.setId(cursor.getInt(0));
                        obj.setJoke(cursor.getString(1));

                        list.add(obj);
                    } while (cursor.moveToNext());
                }

            } finally {
                try { cursor.close(); } catch (Exception ignore) {}
            }

        } finally {
            try { db.close(); } catch (Exception ignore) {}
        }

        return list;
    }

    public boolean search(String joke) {
        Joke j = null;
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + JokeTable.TABLE +
                " where " + JokeTable.COL_J + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[] { joke });

        if (cursor.moveToFirst()) {
            j = new Joke();
            j.setId(cursor.getInt(0));
            j.setJoke(cursor.getString(1));
        }
        if(!j.getJoke().equals(null))
        {
            return true;
        }
        else
        {
            return false;
        }

    }


}
