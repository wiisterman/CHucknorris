package com.kylecolt.chucknorris;

import android.net.Uri;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.method.ScrollingMovementMethod;
import android.util.Log;
import android.view.View;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONStringer;

import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class MainActivity extends AppCompatActivity {

    JokeDatabase jd;
    ArrayList<Joke> j;
    TextView outText;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        outText = findViewById(R.id.output);
        jd = new JokeDatabase(getApplicationContext());
        j = new ArrayList<>();
        outText.setMovementMethod(new ScrollingMovementMethod());

    }

    public void apiGo(View view)
    {
        Uri builtUri1 = Uri.parse("http://api.icndb.com/jokes/random").buildUpon()
                 .build();
        new cnJoke().execute(builtUri1.toString());

    }

    public static String getResponseFromHttpUrl(String url) throws IOException {
        URL theURL = new URL(url);
        HttpURLConnection urlConnection = (HttpURLConnection) theURL.openConnection();
        try {
            InputStream in = urlConnection.getInputStream();

            Scanner scanner = new Scanner(in);
            scanner.useDelimiter("\\A");

            boolean hasInput = scanner.hasNext();
            if (hasInput) {
                return scanner.next();
            } else {
                return null;
            }
        } finally {
            urlConnection.disconnect();
        }
    }




    public class cnJoke extends AsyncTask<String, Void, String> {

        @Override
        protected String doInBackground(String... strings) {


            String toReturn = "DID NOT WORK";
            try {
                toReturn = getResponseFromHttpUrl(strings[0]);

            } catch (Exception e) {
                Log.d("ErrorInApp", "exception on get Response from HTTP call" + e.getMessage());
            }
            return toReturn;
        }

        @Override
        protected void onPostExecute(String jSonToParse) {

            String joke = "";
            JSONObject docs = new JSONObject();

            String value1 = "x";

            try {

                JSONObject sentimentJSON = new JSONObject(jSonToParse);
                docs = sentimentJSON.getJSONObject("value");
                value1 = docs.getString("joke");

            } catch (JSONException e) {
                e.printStackTrace();
            }
            Joke j1 = new Joke();
            j1.setJoke(value1);
            jd.addJoke(j1);
            j = jd.getAllElements();
            outText.setText(j.toString());

        }

    }

}
